import React from 'react'
import { Link } from 'react-router-dom';


export default function Navbar() {
  return (
    <div><div className="navbar bg-gray-600 shadow-sm">
    <div className="flex-1">
      <a className="btn btn-ghost text-xl text-white">LegalEase</a>
    </div>
    
    <div className="flex gap-2">
      
      <div className="dropdown dropdown-end">
        <div tabIndex={0} role="button" className="btn btn-ghost btn-circle avatar">
          <div className="w-10 rounded-full">
            <img
              alt="Tailwind CSS Navbar component"
              src="https://cdn.pixabay.com/photo/2018/04/18/18/56/user-3331257_1280.png" />
          </div>
        </div>
        <ul
          tabIndex={0}
          className="menu menu-sm dropdown-content bg-base-100 rounded-box z-1 mt-3 w-52 p-2 shadow">
          <li className="justify-between">
            
              <Link to="/profile">Profile</Link>
              
            
          </li>
          <li><Link to="/dash">Dashboard</Link></li>
          <li><Link to="/pro">Probono-Register</Link></li>
          <li>
   <Link to="/messages">Messages</Link>
</li>

          
          
       
          
   
  
        </ul>
      </div>
    </div>
  </div></div>
  )
}
